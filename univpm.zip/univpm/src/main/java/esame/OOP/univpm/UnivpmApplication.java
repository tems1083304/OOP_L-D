package esame.OOP.univpm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UnivpmApplication {

	public static void main(String[] args) {
		SpringApplication.run(UnivpmApplication.class, args);
	}

}
